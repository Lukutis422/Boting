# Discord PRO Bot

## Setup

1. Copy `.env.example` to `.env`
2. Add your DISCORD_TOKEN
3. Install dependencies:
   pip install -r requirements.txt
4. Run:
   python bot.py

Slash command: /ping
